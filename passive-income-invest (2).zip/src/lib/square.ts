// Square Payment Integration Service
// Handles payment processing and profit distribution

interface SquareConfig {
  accessToken: string;
  locationId: string;
  accountId?: string;
  merchantId?: string;
  bankAccountId?: string;
  ownerSquareAccountId?: string; // The account to receive 10% fees
  environment: 'sandbox' | 'production';
}

class SquareService {
  private config: SquareConfig | null = null;

  constructor() {
    this.loadConfig();
  }

  private loadConfig() {
    // First check for new API configuration format
    const apiCredentials = localStorage.getItem('api_credentials');
    const productionMode = localStorage.getItem('production_mode') === 'true';
    
    if (apiCredentials) {
      const creds = JSON.parse(apiCredentials);
      if (creds.square) {
        this.config = {
          accessToken: productionMode ? creds.square.accessToken : creds.square.sandboxAccessToken,
          locationId: creds.square.locationId,
          ownerSquareAccountId: creds.square.ownerSquareAccountId,
          bankAccountId: creds.square.bankAccountId,
          environment: productionMode ? 'production' : 'sandbox'
        };
        return;
      }
    }
    
    // Fall back to old config format
    const savedConfig = localStorage.getItem('squareConfig');
    if (savedConfig) {
      this.config = JSON.parse(savedConfig);
    }
  }

  private getHeaders() {
    this.loadConfig(); // Reload config each time to get latest values
    
    if (!this.config?.accessToken) {
      throw new Error('Square API not configured. Please configure your Square API keys in the API Configuration tab.');
    }

    return {
      'Square-Version': '2024-01-18',
      'Authorization': `Bearer ${this.config.accessToken}`,
      'Content-Type': 'application/json'
    };
  }

  private getBaseUrl(): string {
    this.loadConfig();
    return this.config?.environment === 'production' 
      ? 'https://connect.squareup.com'
      : 'https://connect.squareupsandbox.com';
  }

  async createPayment(amount: number, sourceId: string, note?: string) {
    if (!this.config?.locationId) {
      throw new Error('Square Location ID not configured');
    }

    const response = await fetch(`${this.getBaseUrl()}/v2/payments`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        source_id: sourceId,
        idempotency_key: crypto.randomUUID(),
        amount_money: {
          amount: Math.round(amount * 100), // Convert to cents
          currency: 'USD'
        },
        location_id: this.config.locationId,
        note: note || 'Trading profit distribution'
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.errors?.[0]?.detail || 'Payment failed');
    }

    return response.json();
  }

  async createPayout(amount: number, destination: string) {
    if (!this.config?.locationId) {
      throw new Error('Square Location ID not configured');
    }

    const response = await fetch(`${this.getBaseUrl()}/v2/payouts`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        idempotency_key: crypto.randomUUID(),
        location_id: this.config.locationId,
        payout: {
          amount_money: {
            amount: Math.round(amount * 100),
            currency: 'USD'
          },
          destination: {
            type: 'BANK_ACCOUNT',
            id: destination
          }
        }
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.errors?.[0]?.detail || 'Payout failed');
    }

    return response.json();
  }

  // NEW: Process the 10% platform fee distribution to owner's account
  async processPlatformFeeDistribution(totalProfit: number) {
    if (!this.config?.bankAccountId) {
      throw new Error('Owner bank account not configured. Please set up your bank account in Square settings.');
    }

    const platformFee = totalProfit * 0.1; // 10% fee
    
    try {
      // Create a payout to the owner's bank account
      const result = await this.createPayout(platformFee, this.config.bankAccountId);
      
      console.log(`Platform fee of $${platformFee.toFixed(2)} sent to owner's bank account`);
      
      return {
        success: true,
        amount: platformFee,
        payoutId: result.payout?.id,
        status: result.payout?.status,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to process platform fee distribution:', error);
      throw error;
    }
  }

  async processTradingProfit(amount: number, description: string) {
    // Process the actual trading profit and automatically handle the 10% fee
    const platformFee = amount * 0.1;
    const netProfit = amount * 0.9;
    
    try {
      // If configured, send the 10% fee to the owner's account
      if (this.config?.bankAccountId) {
        await this.processPlatformFeeDistribution(amount);
      }
      
      return {
        id: crypto.randomUUID(),
        totalAmount: amount,
        platformFee: platformFee,
        netProfit: netProfit,
        status: 'completed',
        description: description,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error processing trading profit:', error);
      throw error;
    }
  }

  async transferToCashApp(amount: number, cashTag: string) {
    // In a real implementation, this would transfer to Cash App
    console.log(`Transferring $${amount} to ${cashTag}`);
    
    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: crypto.randomUUID(),
          amount: amount,
          recipient: cashTag,
          status: 'completed',
          timestamp: new Date().toISOString()
        });
      }, 1000);
    });
  }

  async getBalance() {
    const response = await fetch(`${this.getBaseUrl()}/v2/cash-drawers/shifts`, {
      headers: this.getHeaders()
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.errors?.[0]?.detail || 'Failed to get balance');
    }

    return response.json();
  }

  isConfigured(): boolean {
    this.loadConfig();
    return !!(this.config?.accessToken && this.config?.locationId);
  }

  getConfig() {
    this.loadConfig();
    return this.config;
  }

  async initiateAutoPayout(amount: number) {
    if (!this.config?.bankAccountId) {
      throw new Error('Bank account not configured for auto-payout');
    }
    
    return this.createPayout(amount, this.config.bankAccountId);
  }

  configure(config: any) {
    // Save configuration to localStorage
    const squareConfig = {
      accessToken: config.accessToken,
      locationId: config.locationId,
      accountId: config.accountId,
      merchantId: config.merchantId,
      bankAccountId: config.bankAccountId,
      ownerSquareAccountId: config.ownerSquareAccountId,
      environment: config.environment,
      autoWithdrawal: config.autoWithdrawal,
      withdrawalThreshold: config.withdrawalThreshold
    };
    
    localStorage.setItem('square_config', JSON.stringify(squareConfig));
    
    // Also save in the new API credentials format
    const existingCreds = localStorage.getItem('api_credentials');
    const creds = existingCreds ? JSON.parse(existingCreds) : {};
    creds.square = {
      accessToken: config.environment === 'production' ? config.accessToken : undefined,
      sandboxAccessToken: config.environment === 'sandbox' ? config.accessToken : undefined,
      locationId: config.locationId,
      bankAccountId: config.bankAccountId,
      ownerSquareAccountId: config.ownerSquareAccountId
    };
    localStorage.setItem('api_credentials', JSON.stringify(creds));
    localStorage.setItem('production_mode', config.environment === 'production' ? 'true' : 'false');
    
    // Reload configuration
    this.loadConfig();
  }

  async verifyConnection(): Promise<boolean> {
    try {
      // Try to fetch balance to verify connection
      await this.getBalance();
      return true;
    } catch (error) {
      console.error('Square connection verification failed:', error);
      return false;
    }
  }
}

export const squareService = new SquareService();
